﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfServiceentity
{
    public class Productlayer
    {
         static Productlayer p = new Productlayer();
        DemodataEntities db = new DemodataEntities();
        private Productlayer() { }
        public List<Product> GetProductl()
        {

            return db.Products.ToList<Product>();
        
        }
        public static Productlayer getProductlayer()
        {
            if (p != null)
                return p;
            else
            {
                p = new Productlayer();
                return p;
            }
        
        }
    }
}