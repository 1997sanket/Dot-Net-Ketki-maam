﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WcfService_Cat
{
    public class EmartRepository:IEmartRepository
    {
        public SqlConnection getconnection()
        {
            SqlConnection sqlconn = new SqlConnection();
            string connstring = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
            sqlconn.ConnectionString = connstring;
            return sqlconn;
        }
        public List<category> GetMyCategory()
        {
            SqlConnection sqlconnection = getconnection();
            sqlconnection.Open();
            SqlCommand sqlcmd = new SqlCommand("select * from category where sub_category_name is null", sqlconnection);
            SqlDataReader sqldata = sqlcmd.ExecuteReader();
            List<category> list = new List<category>();
            while (sqldata.Read())
            {
                category c = new category();
                c.category_id = Convert.ToInt32(sqldata["category_id"].ToString());
                c.category_name = sqldata["category_name"].ToString();
                c.sub_category_name = sqldata["sub_category_name"].ToString();
                c.product_name = sqldata["product_name"].ToString();
                c.imagepath = sqldata["imagepath"].ToString();
                c.direct_product = sqldata["direct_product"].ToString();
                list.Add(c);
            }
            return list;
        }

       
    }
}