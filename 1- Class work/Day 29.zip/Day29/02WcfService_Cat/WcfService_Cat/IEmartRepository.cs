﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfService_Cat
{
    public interface IEmartRepository
    {
        List<category> GetMyCategory();
    }
}