﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WcfService_Cat
{
    [DataContract]
    public class category
    {
        [DataMember]
        public int category_id { get; set; }

        [DataMember]
        public String category_name { get; set; }

        [DataMember]
        public String sub_category_name { get; set; }

        [DataMember]
        public String product_name { get; set; }

        [DataMember]
        public String imagepath { get; set; }

        [DataMember]
        public String direct_product { get; set; }


    }
}