  
  angular.module("emartapp").config(['$routeProvider',  function($routeProvider) {
             $routeProvider.
                when('Home/HTC.cshtml', {
                    templateUrl: 'HTC.cshtml',
                    controller: 'emartcontrollerr'
                }).
                when('/', {
                    templateUrl: 'Index.html',
                    controller: 'emartcontroller'
                }).
                otherwise({
                    redirectTo: '/'
                });
         }]);


