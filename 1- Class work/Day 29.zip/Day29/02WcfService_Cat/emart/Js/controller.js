/// <reference path="~/js/angular.js" />  
/// <reference path="~/js/Module.js" />  
/// <reference path="~/js/service.js" />  

angular.module("emartapp").controller("emartcontroller", function ($scope, emartservice) {
    // alert("PreIndex");
    
   
    GetCategory();
    //To Get All Records  
    function GetCategory() {
      
        var promiseGet = emartservice.GetCategory();
        promiseGet.then(function (pl) { $scope.category = pl.data },
              function (errorPl) {
                  console.log('Some Error in Getting Records.', errorPl);
              });
    }
})

    