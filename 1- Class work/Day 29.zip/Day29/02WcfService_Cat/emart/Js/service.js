/// <reference path="~/js/angular.js" />  
/// <reference path="~/js/Module.js" />

 angular.module("emartapp").service("emartservice", function ($http) {
	
    this.GetCategory = function () {  
        return $http.get("http://localhost:17253/EmartService.svc/GetCategory");
	}

	this.GetCategoryByName = function (product_name) {
	    return $http.get("http://localhost:50524/EmartService.svc/GetCategory/"+product_name);
	}


	this.GetProduct = function (category_id) {
	    return $http.get("http://localhost:50524/EmartService.svc/GetProduct/" + category_id);
	}

	this.GetProductParameter = function (pid) {
	    return $http.get("http://localhost:50524/EmartService.svc/GetProductParameter/" + pid);
	}

http://localhost:51591/Views/Account
	this.SetInvoiceD = function(prod,cid)
	{
	    var request = $http({
	        method: "get",
	        url: "http://localhost:50524/EmartService.svc/SetInvoiceDetail/" + prod.productid + "/" + prod.price + "/" + cid
	    });
	    return request;
	}
	this.parte = function (user) {
	    var request = $http({
	        method: "get",
	        url: "http://localhost:50524/EmartService.svc/SetUser/" + user.uname + "/" + user.password + "/" +  user.gender + "/" +  user.choice


	    });
	    return request;
	}

	this.pwdcheck = function (login) {
	    return $http.get("http://localhost:50524/EmartService.svc/CheckUser/" + login.uname + "/" + login.pwd);
	}

	//this.pwdcheck = function (pass) {
	//    var request = $http({
	//        method: "get",
	//        url: "http://localhost:50524/EmartService.svc/CheckUser/" + pass.uname + "/" + pass.pwd
	//    });
	//    return request;
	//}


	this.SetRegistration = function (register) {
	    var request = $http({
	        method: "get",
	        url: "http://localhost:50524/EmartService.svc/SetRegistration/" + register.fname + "/" + register.lname + "/" + register.uname + "/" + register.pwd + "/" + register.bname + "/" + register.lmark + "/" + register.area + "/" + register.city + "/" + register.state + "/" + register.pincode + "/" + register.email + "/" + register.phone + "/" + register.gender + "/" + register.ecart
	    });
	    return request;
	}



	this.SetInvoiceHead = function (custid) {
	    return $http.get("http://localhost:50524/EmartService.svc/SetInvoiceHead/" + custid);
	}

	this.GetCust = function (custid) {
	    var request = $http({
	        method: "get",
	        url: "http://localhost:50524/EmartService.svc/GetCustomer/" + custid
	    });
	    return request;
	}

	this.GetItemDetails = function (inv) {
	    var request = $http({
	        method: "get",
	        url: "http://localhost:50524/EmartService.svc/GetItemDetails/" + inv
	    });
	    return request;
	}

});